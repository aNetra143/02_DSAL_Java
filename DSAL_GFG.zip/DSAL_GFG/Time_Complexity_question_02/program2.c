//find the time complexity of the program given below:
#include <stdio.h>
void func(int n){
    int sum = 0;
    int product = 1;
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            printf("%d, %d\n",i,j);
        }
    }
}
int main(){
    func(23);
    return 0;
}