//This Prorgam has been taken from the Codingninjas.com 

#include <stdio.h>

int main(){
    int n;//10
    for(int i = n/2; i<n; i++){
        for(int j = 0; j < n; j = j*2){
            printf("%d %d",i,j);
        }
    }
    return 0;
}