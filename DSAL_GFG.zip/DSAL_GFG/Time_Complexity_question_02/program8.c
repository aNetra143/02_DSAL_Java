// Find the time complexity of the given problem.
#include <stdio.h>

int main(){
    int k = 1;
    int n;//let say input = 10;
    while(k<=n){
        printf("%d",k);
        k = k*2;
    }
    return 0;
}