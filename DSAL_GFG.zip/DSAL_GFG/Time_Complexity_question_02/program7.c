// Find the time complexity of the given program.
// This prorgam has taken from the codingninjas.com
#include <stdio.h>

int main(){
    int n;
    for(int i=0; i<n;i++){
        printf("%d",i);
    }

    for(int j=0; j<n;j++){
        printf("%d",j);
    }

    return 0;
}