
/* 
Amazon
int count = 0;
for (int i = N; i > 0; i /= 2) {
    for (int j = 0; j < i; j++) {
        count += 1;
    }
}

O(1) time doesn't imply that the runtime is constant,

ArrayList<String> names = new ArrayList<String>(10);

10 items add store capacity.
20 items names add : 20 items extra space --> Space Complexity:

names  : 10 items store cpy.
copy: 30 items size allocate.: 20 items -> extra space

Q1. TC ?
int a = 0, b = 0;
Space Complexity:- O(1)
for (let i = 0; i < n; ++i) {
    a = a + i;
    First time complexity: t1 = Linearly: O(n)
}
for (let j = 0; j < m; ++j) {
    b = b + j;
    First time complexity: t2 = Linearly: O(m)
}

log: Multiplication
Ans: t1 + t2 = O(n) + O(m)
             = O(n+m)

Q2. 
int a = 0, b = 0;
Space Complexity:- O(1)
for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
        a = a + j; t3 = O(n)
    }
    t1 = O(n^2)
}
for (int k = 0; k < n; ++k) {
    b = b + k;  t4 = O(n)
    t2 = O(n)
}
tsum = t1 + t2 + t3 + t4
     = O(n^2) + O(n) + O(n) + O(n)
     = O(n^2)


int a;//declaration
a = ?

Q3. TC and SC ?
let a = 0;
for (int i = 0; i < n; ++i) { 
    for (int j = n; j > i; --j) {
        a = a + i + j;
    }
}
Ans: tsum = O(n^2)

Q4. Time Complexity?
n = 1000; 
if the value of i starts from the i 
for (int i = n; i > 0; i = Integer.parseInt(i / 2)) {
    System.out.println(i);
}
Time complexity: O(log n)


*/