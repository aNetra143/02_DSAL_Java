package DSAL_GFG.LinearSearch_03;

public class squareRoot_07 {

    public static int findSquareRoot(int x){
        int low = 1, high = 16;
        int ans = -1;
        while(low<= high){
            int mid = (low+high)/2;
            int mSquare = mid * mid;
            if(mSquare == x){
                return mid;
            }else if(mSquare > x){
                high = mid - 1;
            }else{
                low = mid + 1;
                ans = mid;
            }
        }
        return ans;
    }
    public static void main(String[] args) {

        System.out.println("The square root of the given number is:= "+findSquareRoot(16));
        
    }
    
}
