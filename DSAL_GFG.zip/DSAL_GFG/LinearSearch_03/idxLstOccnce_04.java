package DSAL_GFG.LinearSearch_03;

public class idxLstOccnce_04 {

    public static int findLastOccurence(int arr[],int n, int x){
        int low = 0, high = n-1;
        while(low<=high){
            int mid = (low+high)/2;
            if(arr[mid]>x){
                high = mid - 1;
            }else if(arr[mid]<x){
                low = mid + 1;
            }else{
                if(mid != n-1 || arr[mid] != arr[mid+1]){
                    return mid;
                }else{
                    low = mid+1;
                }
            }
        }
        return -1;
    }

    // Time complexity: O(logn).
    // Auxillary Space: O(1).
    public static void main(String[] args) {
        int[] arr = {1,2,3,4,5,5,5,5,5};
        int n = 9;
        int x = 5;
        int idx = findLastOccurence(arr, n, x);
        System.out.println("The element is present at this index:- "+idx);
    }
    
}
