package DSAL_GFG.LinearSearch_03;

public class iterativeBS_01 {

    public static int binarySearch(int number[], int x, int numbeOfElement){
        int low = 0;
        int high = numbeOfElement-1;
        while(low <= high){
            int mid = (low + high) / 2;
            if(number[mid] == x){
                return mid;
            }
            else if(number[mid] > x){
                high = mid - 1;
            }else{
                low = mid + 1;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        int[] number = {1,4,7,9,13,25,46,78,90,223};
        int numbeOfElement = 10;
        int x = 25;
        binarySearch(number, x, numbeOfElement); 
        System.out.println("The element is present at index: "+binarySearch(number, x, numbeOfElement));
        
    }
    
}
