package DSAL_GFG.LinearSearch_03;

public class count1sSA_06 {

    public static int countOnes(int number[], int n){
        int low = 0, high = n - 1;
        while(low<=high){
            int mid = (low+high)/2;
            if(number[mid] == 0){
                low = mid+1;
            }else{
                if(mid == 0 || number[mid-1] == 0 ){
                    return (n-mid);
                }else{
                    high = mid - 1;
                }
            }
        }
        return -1;
    }

    public static void main(String[] args) {

        int[] number = {0,0,0,0,0,1,1,1,1,1,1,1,1,1,1};
        int n = 15;
        System.out.println("The number of 1s present in the given arrays is: "+countOnes(number, n));
        
        
    }
    
}
