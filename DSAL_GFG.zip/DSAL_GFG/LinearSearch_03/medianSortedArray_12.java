package DSAL_GFG.LinearSearch_03;

public class medianSortedArray_12 {

    /*
     * Naive: O(n1+n2)*log(n1+n2).
     * n1: size of a1[].
     * n2: size of a2[].
     * Process:
     * -> Create an array temp[] of size(n1+n2).
     * -> Copy elements of a1[] and a2[] to temp[].
     * -> Sort temp[].
     * -> if (n1+n2) is Odd, then return middle of temp.
     * -> Else return average of middle two elements.
     */

     // Efficient Solution: O(logn1) Where n1<=n2.

    
    // public static int medianTwoSortedArr(int a1[], int a2) {

    // }

    public static void main(String[] args) {
        // int[] a1 = { 10, 20, 30, 40, 50 };
        // int[] a2 = { 5, 15, 25, 35, 45 };

    }

}
