package DSAL_GFG.LinearSearch_03;

public class countOccrnce_05 {

    // Count the number of occurences in the sorted arrays:
    public static int findFirstOccurence(int number[], int n, int x){
        int low = 0, high = n-1;
        while(low<=high){
            int mid = (low+high)/2;
            if(number[mid] > x){
                high = mid - 1;
            }else if(number[mid] < x){
                low = mid + 1;
            }else{
                if(mid == x || number[mid] != number[mid-1]){
                    return mid;
                }else{
                    high = mid - 1;
                }
            }
        }
        return -1;
    }

    public static int findLastOccurence(int number[], int n, int x){
        int low = 0, high = n - 1;
        while(low<=high){
            int mid = (low+high)/2;
            if(number[mid]>x){
                high = mid - 1;
            }else if(number[mid]<x){
                low = mid + 1;
            }else{
                if(mid == n-1 || number[mid] != number[mid+1]){
                    return mid;
                }else{
                    low = mid+1;
                }
            }
        }
        return -1;
    }

    public static int countOccurence(int number[], int n, int x){
        int firstOcrnce = findFirstOccurence(number, n, x);
        if(firstOcrnce == -1){
            return 0;
        }else{
            return findLastOccurence(number, n, x) - firstOcrnce+1;
        }
    }

    public static void main(String[] args) {
        int[] number = {10,20,20,20,20,20,20,20,30,30,40,50,60,70};
        int n = 14;
        int x = 20;
        System.out.println("The count of the given element is: "+countOccurence(number, n, x));

    }

}
