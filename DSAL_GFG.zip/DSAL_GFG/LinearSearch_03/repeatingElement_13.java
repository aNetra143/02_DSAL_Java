package DSAL_GFG.LinearSearch_03;

public class repeatingElement_13 {


    /*
     * -> Given an array size: n>=2
     * -> Only one element repeats(any number of times.).
     * -> All the elements from 0 to max(arr) are present.
     * -> therefore, 0 < max(arr) <= n-2.
     * we need to solve these problem on:
     * -> O(n) : Time Complexity.
     * -> O(1) : Auxillary Space.
     * -> No Magnifications to the original arrays.
     */


     /*

        Super naive solution:
        -> O(n^2) Time and O(1) Space.
        for(int i = 0; i < n; i++){
            for(int j = i+1; j < n; j++){
                if(arr[i] == arr[j]){
                    return arr[i];
                }
            }
        }


        Naive Solution: O(nlogn) Time and O(1) Auxillay Space.
        1. Sort the array: arr[] = {0,1,2,2,2,2,3,4,5};
        2. for(int i = 0; i < n-1; i++){
            if(arr[i] == arr[n-1]){
                return arr[i];
            }
        }


        Efficient Approach:
        -> O(n) : Time and O(n) : Auxillary Space.
        1. Create a boolean array of size n-1.
        2. for(int i = 0; i < n; i++){
            if(visited[arr[i]]){
                return arr[i];
            }
            visited[arr[i]] = true;
        }

     */

    public static int repeatingElement(int arr[], int n){
        boolean visit[] = new boolean[n];
        for (int i = 0; i < n; i++) {
            if(visit[arr[i]]){
                return arr[i];
            }
            visit[arr[i]] = true;
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] arr = {0,2,3,1,2,2,2,6,5,7};
        int n = 10;
        System.out.println("The repeating element is: "+repeatingElement(arr, n));

    }

}
