package DSAL_GFG.LinearSearch_03;

public class idx1stOccnc_03 {
    // Our task is to find the index of first occurence in the array:
    public static int find1stOccurence(int number[], int n, int x){
        int low = 0;
        int high = n-1;
        while(low<=high){
            int  mid = (low+high)/2;
            if(number[mid] > x){
                high = mid - 1;
            }else if(number[mid] < x){
                low = mid + 1;
            }else{
                if(mid == x || number[mid-1] != number[mid]){
                    return mid;
                }else{
                    high = mid - 1;
                }
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] number = {10,12,1,3,16,17,19,20,23,25,25,26,37,58};
        int x = 25;
        int n = 14;
        System.out.println("The number is present at index: "+find1stOccurence(number, n, x));
    }
    
}
