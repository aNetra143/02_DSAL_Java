package DSAL_GFG.LinearSearch_03;

//  O(Log n) approach to search an element in a sorted and rotated array.
public class searchSortedRotateArray_09 {

    public static int findSortedRotatedArr(int number[], int x){
        int n = 15; 
        int low = 0, high = n - 1;
        while(low<=high){
            int mid = (low+high)/2;
            if(number[mid] == x){
                return mid;
            }
            // Checking for the left side.
            if(number[mid]> number[low]){
                if(x>= number[low] && x <= number[mid]){
                    high = mid - 1;
                }else{
                    low = mid + 1;
                }
            }else{
                // Checking for the right side.
                if(x>=number[mid] && x <= number[high]){
                    low = mid + 1;
                }else{
                    high = mid - 1;
                }
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] number = {9,12,14,15,17,18,19,20,22,25,1,4,6,7,8};
        int x = 1;
        System.out.println("The number present in the sorted Rotate Array is lies at the index:- "+findSortedRotatedArr(number, x));
    } 
}
