package DSAL_GFG.LinearSearch_03;


public class searchInfiniteSortedArray_08 {
    /*
     * #. Search in Infinite Sized Array
     * Find the element in the infinite sorted arrays:
     */

    public static int binarySearch(int number[], int low, int high, int x){
        if(low>high){
            return -1;
        }
        int mid = (low+high)/2;
        if(number[mid] == x){
            return mid;
        }else if(number[mid] > x){
            return binarySearch(number, low,mid-1, x);
        }else{
            return binarySearch(number,mid+1, high, x);
        }
    }

    public static int search(int number[], int x){
        if(number[0] == x){
            return 0;
        }
        int i = 1;
        while(number[i]<x){
            i = i*2;
        }
        if(number[i] == x){
            return i;
        }
        return binarySearch(number, i/2+1, i-1, x);
    }

    // Time complexity: O(log Position).
    public static void main(String[] args) {
        int[] number = {1,2,3,40,50};
        int x = 24;
        System.out.println("The given number is present at the index: "+search(number, x));

    }
}
