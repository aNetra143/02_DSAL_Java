package DSAL_GFG.LinearSearch_03;

public class peakElementUnsortedArray_10 {

    // Find the peak element in the unsorted array.
    // The element that is not smaller than its neighbours element. 

    public static int peakElement(int number[], int n){
        int low = 0, high = n-1;
        while(low<=high){
            int mid = (low+high)/2;
            if((mid == 0 || number[mid] >= number[mid-1]) && (mid==n-1 || number[mid] >= number[mid+1])){
                return mid;
            }

            if(mid>0 && number[mid-1] >= number[mid]){
                high = mid - 1;
            }else{
                low = mid + 1;
            }
        }
        return -1;
    }

    // It always return the first peak element that is present in the array.

    public static void main(String[] args) {
        int[] number = {2,3,64,112,800,9,4};
        int n = 7;
        System.out.println("The peak element in the unsorted array is:- "+peakElement(number, n));
    }
    
}
