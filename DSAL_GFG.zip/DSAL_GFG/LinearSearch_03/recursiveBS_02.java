package DSAL_GFG.LinearSearch_03;

import java.util.Scanner;

public class recursiveBS_02 {

    public static int recursiveBS(int number[],int elmtToBeSearch, int low, int high){
        
        if(low > high){
            return -1;
        }
        int mid = (low+high)/2;

        if(number[mid]==elmtToBeSearch){
            return mid;
        }else if(number[mid] > elmtToBeSearch){
            high = mid -1;
            return recursiveBS(number,elmtToBeSearch,low,high);
        }else{
            low = mid + 1;
            return recursiveBS(number, elmtToBeSearch,mid+1,high);
        }
    }

    public static void main(String[] args) {
        int[] number = {1,2,3,5,6,7,8,9,12,14,15,16,24,35,56};
        int low = 0;
        int n = 15;
        int high = n - 1;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter an element to be search: ");
        int elmtToBeSearch = sc.nextInt();
        System.out.println("The element is present at index:- "+recursiveBS(number,elmtToBeSearch,low,high));  
        sc.close();      
    }
    
}
