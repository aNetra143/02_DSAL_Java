package DSAL_GFG.LinearSearch_03;

public class twoPointerApproach_11 {

    /*
     * Find an unsorted array and a number x, we need to find if there is a pair in
     * the array with sum equals to x.
     */
    public static boolean twoPointer(int number[], int x) {
        int n = 7; // Number of elements that is present in the given arrays.
        int left = 0, right = n - 1;
        while (left < right) {
            if (number[left] + number[right] == x) {
                return true;
            } else if (number[left] + number[right] > x) {
                right--;
            } else {
                left++;
            }
        }
        return false;
    }

    /*
     * Given an sorted array and a sum, find if there is a pair with given sum.
     * Two Pointer Approach.
     * If the array is sorted then the hasing is good.
     */

    /*
     * Given a sorted array and a sum, find if there is a triplet with given sum.
     */

    /*
     * Q1. Count Pairs with given sum.
     * Q2. Count Triplets with given sum.
     * Q3. Find if there is a triplet a,b,c such that a^2 + b^2 = c^2.
     */
    public static void main(String[] args) {

        int[] number = { 3, 5, 9, 2, 8, 10, 11 };
        int sumOfTwoNumber = 18;
        System.out.println(twoPointer(number, sumOfTwoNumber));

    }

}
