package DSAL_GFG.Array_02;

public class majorityElement_21 {
    /*
     * Majority Element is an element that appears more than n/2 times in an array
     * of size n. In this
     * ,two methods to find the maority element in an array.
     * Moore's Voting Algorithm.
     */
    static int findMajority(int arr[], int n) {
        int res = 0, count = 1;
        for (int i = 1; i < n; i++) {
            if (arr[res] == arr[i])
                count++;
            else
                count--;
            if (count == 0) {
                res = i;
                count = 1;
            }
        }

        count = 0;
        for (int i = 0; i < n; i++) {
            if (arr[res] == arr[i]){
                count++;
            }      
        }

        if (count <= n / 2){
            res = -1;
        } 
        return res;
    }

    public static void main(String args[]) {
        int arr[] = { 8, 8, 6, 6, 6, 4, 6 }, n = 7;

        System.out.println("The majority element in the array is:- ");
        System.out.println(findMajority(arr, n));
        
    }
}
