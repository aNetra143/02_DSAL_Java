package DSAL_GFG.Array_02;

import java.util.Arrays;

public class reverseArray_08 {

    public static void reverseArray(int number[]){
        int size = number.length;
        // Low is indicating 0th index element of the array and high is indicating last index element of the arrays.
        int low = 0, high = size - 1;
        while(low < high){
            int temp = number[low];
            number[low] = number[high];
            number[high] = temp;
            low++; 
            high--;
        }
    }

    public static void main(String[] args) {
        // first element is called -> low
        // last element is called -> high
        int[] number = {2,4,5,7,8,9,1,0,20};
        System.out.println("Before Reversing the arrays: "+Arrays.toString(number));
        reverseArray(number);
        System.out.println("After Reversing the arrays: "+Arrays.toString(number));
        

    }
    
}
