package DSAL_GFG.Array_02;

public class maxSumArray_18 {

    //Sum of the maximum sum array with consecutive 

    // Explanation of Kadane's Algorithm
    // kadane's algorithm does not take any -ve value if return sum is in -ve.
    // number = {-5,4,6,-3,4,-1};

    public static int getMaxSumOfSubArray(int sumSubArray[]){

        int currentSum = sumSubArray[0];
        int maxSum = sumSubArray[0];
        int n = sumSubArray.length;
        for (int i = 1; i < n; i++) {
            currentSum = Math.max(currentSum+sumSubArray[i], sumSubArray[i]);
            maxSum = Math.max(currentSum, maxSum);
        }
        return maxSum;
        
    }

    public static void main(String[] args) {
        int[] sumSubArray = {2,3,-7,6,-1,5,8};
        System.out.println("\nThe maximum sum of the sub array is: "+getMaxSumOfSubArray(sumSubArray));
        getMaxSumOfSubArray(sumSubArray);
        System.out.println("\n");
        
    }
    
}
