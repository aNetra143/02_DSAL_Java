package DSAL_GFG.Array_02;

public class secondLargest_06 {

    /*
        Assumption:
        Given array is:
        number = {10,5,8,20}; --> return index of second largest element in the arrays. So.
        number = {20,10,20,8,12}; --> return index of 12 bcz 12 is the second largest element in the arrays so.
        number = {10,10,10}  --> return -1 on this case.
    */

    // More Efficient Way to find the Second Largest Elements from the arrays:
    // number = [21,30,10,60,89,20]
    public static int SecondLgstElmntIdx(int number[]){
        int result = -1, lgstElmntIdx = 0;
        for (int i = 0; i < number.length; i++) {
            if(number[i] > number[lgstElmntIdx]){
                result = lgstElmntIdx;
                lgstElmntIdx = i;
            }else if(number[i] != number[lgstElmntIdx]){
                if(result == -1 || number[i] > number[result]){
                    result = i;
                }
            }
        } 
        return 23;
    }
    public static void main(String[] args) {

        int[] number = {210,110,30,204,1,16,7};

        System.out.println("The More Efficient Way to Approach to get the Second Largest Element's Index: ");
        System.out.println("The Second Largest Element is at index: "+SecondLgstElmntIdx(number));


    }
    
}
