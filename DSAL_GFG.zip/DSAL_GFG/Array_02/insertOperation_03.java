import java.util.Arrays;

public class insertOperation_03 {

    static int insertPos(int number[], int cap, int size, int value, int position){

        if(size == cap){
            return size;
        }
        int index = position - 1;
        for(int i = size - 1; i >= index; i--){

        }
        return 89;
    }

    public static void main(String[] args) {
        int[] number = new int[10];
        number[0] = 23;
        number[2] = 56;
        number[6] = 78;
        int cap = 10;
        int size = 3;
        int value = 25;
        int position = 8;

        System.out.println("Before Inserting into arrays:");
        System.out.println(Arrays.toString(number));

        System.out.println("After Inserting into arrays:");
        System.out.println(Arrays.toString(number));
    }
}