package DSAL_GFG.Array_02;

public class stockBuyAndSell_15 {

    // Find the maximum profit after selling the stocks.
    // if the arrays is sorted with increasing order, always sell the stock at end day.

    // This Below is the naive solution to calculate maximum profit from the given stocks:
    public static int stockBuySell(int stock[], int startIndex, int endIndex){
        
        // check whether start index is greater or not if end is not greater than program exit returning 0 to the program.
        if(endIndex <= startIndex){
            return 0;
        }
        int n = stock.length;
        int profit = 0;
        for (int i = startIndex; i < n; i++) {
            for (int j = i+1; j <= endIndex; j++) {
                // price of the j always should greater than i.
                if(stock[j] > stock[i]){
                    int current_Profit = (stock[j] - stock[i]) + stockBuySell(stock, startIndex, i-1) + stockBuySell(stock, j+1, endIndex);
                    profit = Math.max(profit, current_Profit);
                }
            }
        }
        return profit;
    }


    // Most Efficient Method to solve the stock buy and sell problems
    public static int getMaxProfitFromStock(int priceOfStock[]){

        int maxProfit = 0;
        for (int i = 1; i < priceOfStock.length; i++) {
            if(priceOfStock[i] > priceOfStock[i-1]){
                maxProfit += priceOfStock[i] - priceOfStock[i-1];
            }
        }
        return maxProfit;
    }
    //Time Complexity: O(n) and Space Complexity: O(1).


    public static void main(String[] args) {
        // showing the cost of stocks.
        int[] stock = {1,6,8,112,5,17,12}; // answer will be 123:
        int n = stock.length;
        System.out.println("The maximum profit from the day stock buy and stock sell is: "+stockBuySell(stock, 0, n-1));


        // More Efficient Solution for the stock buy and sell the stocks.
        int[] priceOfStock = {1,5,30,6,8,92,4}; // 4+25+2+84 => 115 
        System.out.println("The maximum profit with stocks is: "+getMaxProfitFromStock(priceOfStock));


        
    }
    
}
