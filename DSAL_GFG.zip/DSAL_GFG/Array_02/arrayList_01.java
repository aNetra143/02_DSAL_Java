package DSAL_GFG.Array_02;

import java.util.ArrayList;

public class arrayList_01 {
    public static void main(String[] args) {

        /*
            Notes:- 
            We cannot create an ArrayList of primitive type like integers, float.
            ========================
            Syntax of the arraylist:
            ========================
            Arraylist<String> namesOfStudents = new ArrayList<String>(10);
        */

        ArrayList<Integer> age = new ArrayList<Integer>(10);
        age.add(19);
        age.add(20);
        age.add(21);
        age.add(22);
        System.out.println(age);




        
    }
    
}
