package DSAL_GFG.Array_02;

public class MaxConsecutive1_17 {

    public static int getMaxConsecutive1(int onesBinaryArray[]){
        int n = onesBinaryArray.length;
        int currentResult = 0;
        int result = 0;
        for (int i = 0; i < n; i++) {
            if(onesBinaryArray[i] == 0){
                currentResult = 0;
            }else{
                currentResult++;
                result = Math.max(result, currentResult);
            }
            
        }
        return result;

    }
    public static void main(String[] args) {
        int[] onesBinaryArray = {1,0,1,1,1,1,1,1,1,0,1,1};
        System.out.println("\n");
        System.out.println("The maximum consecutive one's from the arrays is: "+getMaxConsecutive1(onesBinaryArray));
        System.out.println("\n");
        
    }
    
}
