import java.util.Arrays;
import java.util.Scanner;

public class searchNumber_04 {
    /*
     * Array to check either number is present in this array or not.
     */
    static int search(int arr[], int n, int x) {
        for (int i = 0; i < n; i++) {
            if (arr[i] == x) {
                return i;
            }
        }
        return -1;
    }
    // Time Complexity: O(n).

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.println("Enter any number you want to check either these number is present in the array or not:");
        int x = scan.nextInt();

        int arr[] = { 10, 20, 30, 4, 2, 1, 5 };
        int n = arr.length;
        int returnIndexNumber = search(arr, n, x);
        if (returnIndexNumber == 1) {
            System.out.println("The number is present in this array.So,");
            System.out.println("the index is: " + returnIndexNumber);
        } else {
            System.out.println("The number is not present in this array. So,");
            System.out.println("The return index is: " + returnIndexNumber);
        }
       scan.close();
    }
}
