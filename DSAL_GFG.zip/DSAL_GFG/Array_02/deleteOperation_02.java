import java.util.Arrays;

public class deleteOperation_02 {

    public static int deleteItems(int number[], int size, int itemToBeDeleted){

        /*
        number = [1,3,4,5,62,6,26];
        itemToBeDeleted = 5;
        Loops run untils the items found.
        
        */
        int i = 0;
        for(i = 0;i<size; i++){
            if(number[i] == itemToBeDeleted){
                break;
            }
        }
        //if the element is not present in the given array, then i will be equals to n bcz i iterate up to n.
        if(i == size){
            return size;
        }

        //this loop run from the itemToBeDeleted up to n-1 times bcz the one item 
        for(int j = i; j < size-1;j++){
            number[j] = number[j+1];
        }
        return size -1;

    }

    public static void main(String[] args) {

        int[] number = { 2, 6, 5, 23, 45, 13 };
        int itemToBeDeleted = 23;
        int size = 6;

        System.out.println("Before Deleting some values of the arrays: "+Arrays.toString(number));

        int sizeAfterDeletion = deleteItems(number, size, itemToBeDeleted);

        System.out.print("After Deleting some values of the arrays: ");
        for(int i = 0; i<sizeAfterDeletion; i++){
            System.out.print(number[i]+" ");
        }
        System.out.println("\n");



        /*
         * Insert: O(n).
         * Search: O(n) -> For unsorted array.
         * O(logn) -> For sorted array.
         * Delete: O(n).
         * get i-th element: O(1).
         * update i-th element: O(1).
         * Note:- insert at the end and delete from the end can be done in O(1) time.
         */
    }

}
