
package DSAL_GFG.Array_02;


public class checkSortedArray_07 {

    // Checking an array for increasing order !
    // Naive solution to solve this problems is not good because nested for loop is used.
    // So the time complexity is O(n^2) in worst case.

    public static boolean checkSortArray(int number[]){

        for (int i = 1; i < number.length; i++) {
            if(number[i] < number[i-1]){
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        
        int[] number = {12,23,24,25,26,27,28};
        boolean returnValue = checkSortArray(number);
        System.out.println("Displaying an array condition:");
        if(returnValue == true){
            System.out.println("Sorted.");
        }else{
            System.out.println("Not Sorted.");
        }


    }
    
}
