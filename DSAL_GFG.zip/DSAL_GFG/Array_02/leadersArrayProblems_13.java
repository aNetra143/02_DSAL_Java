
package DSAL_GFG.Array_02;
import java.util.Arrays;

public class leadersArrayProblems_13 {

    /*
     * Leaders on the array problems.
     * In sorted array with increasing order, only the last element of the array is
     * leader bcz the element after that element is not greater than that .
     * For eg:-
     * number = {7,10,29,2,6,12,3,6,22}
     * ans: In an above problems, only 29 and 22 are the leaders bcz after 29, no
     *      items is greater than that 29 and in case of 22, no items is greater than 29.
     *      So, the items 29 and 22 are leaders in the arrays.
     */

     // Functions to calculate the leaders from the arrays:
    public static void getLeaderElements(int number[]){
        int n = number.length;
        int currentLeader = number[n - 1];
        for (int i = n-2; i >= 0; i--) {
            if(currentLeader < number[i]){
                currentLeader = number[i];
                System.out.println("Current Leader is: "+currentLeader);
            }
        }  
    }


    public static void main(String[] args) {
        
        int[] number = { 1, 2, 30, 4, 50, 6, 7, 88, 22,73,67,45,9};
        System.out.println("Before Calculating an leaders Elements from the unsorted array: "+Arrays.toString(number));
        getLeaderElements(number);
        System.out.println("After Calculating an leader Elements from the unsorted array: "+Arrays.toString(number));
        System.out.println("\n");
    }

}
