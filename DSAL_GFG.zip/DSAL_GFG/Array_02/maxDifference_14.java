public class maxDifference_14 {

    // Maximum value of arr[j]-arr[i] such that j > i:
    public static void main(String[] args) {

        int[] number = {2,3,4,5,6,8,10,24,16,9};

    }
    
}
