package DSAL_GFG.Array_02;

public class maxDifference_14 {
    // Maximum value of arr[j]-arr[i] such that j > i:
    public static int maxDifference(int number[]){
        
        int maxDiff = number[1] - number[0];
        int minValue = number[0];
        for (int j = 1; j < number.length; j++) {
            maxDiff = Math.max(maxDiff, number[j]- minValue);
            minValue = Math.min(minValue, number[j] );
        }
        return maxDiff;
    }

    public static void main(String[] args) {
        int[] number = {2,3,1,5,60,8,10,24,16,9};
        // maxDifference(number);
        System.out.println("The maximum difference is: "+maxDifference(number));
    }
    
}
