import java.util.Arrays;

public class moveAllZerosToEnd_10 {

    /*
        Moving all Zeros to the End:
        -> number = [10,20,30,0,0,0,2,10,0,1]
        -> number = [10,20,30,40,50,60]
        -> number = [0,0,0,0,1,0,1,0]
        Time Complexity:- O(n).
        Space Complexity:- O(1).

    */

    public static int movesAll0sToEnd(int number[]){
        int count = 0;
        for (int i = 0; i < number.length; i++) {
            if(number[i] != 0){
                int temp = number[i];
                number[i] = number[count];
                number[count] = temp;
                count++;
            }
        }
        return count;

    }

    public static void main(String[] args) {
        int[] number = {10,20,30,0,0,0,2,10,0,1};

        System.out.println("Before Moving Zeros to the End of the arrays: ");
        System.out.println(Arrays.toString(number));

        movesAll0sToEnd(number);

        System.out.println("After Moving All Zeros to the End of the arrays: ");
        for (int i = 0; i < number.length; i++) {
            System.out.print(number[i] +" ");
        }

        System.out.println("\n");   
    }
    
}
