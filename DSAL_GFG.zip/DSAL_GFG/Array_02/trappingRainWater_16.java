package DSAL_GFG.Array_02;

public class trappingRainWater_16 {
    // Most Important question for the interview:
    /*
    Given an array of non-negative integers
    values represented in the arrays is the height of the bars.
    Notes:
    if an array is in increasing order or decreasin order, 
    then bars contains Zeros water means bars cannot stores 
    any water.
    Array Preprocessing is used here.
    */

    public static int getTotalUnitOfWater(int bars[]){
        int n = bars.length;
        int[] leftMaxBar = new int[n];
        int[] rightMaxBar = new int[n];

        leftMaxBar[0] = bars[0];
        for (int i = 1; i < n; i++) {
            leftMaxBar[i] = Math.max(leftMaxBar[i-1], bars[i]);
        }

        rightMaxBar[n-1] = bars[n-1];
        for (int i = n-2; i >= 0; i--) {
            rightMaxBar[i]  = Math.max(rightMaxBar[i+1], bars[i]);
        }

        int totalAmountOfWaterStored = 0;
        for (int i = 1; i < rightMaxBar.length; i++) {
            totalAmountOfWaterStored += Math.min(leftMaxBar[i], rightMaxBar[i]) - bars[i] ;
        }

        return totalAmountOfWaterStored;
    }

    public static void main(String[] args) {
        int[] bars = {3,1,2,4,0,1,3,2};// ans must be 8
        System.out.println("The total unit of water that can stored in the bars is: "+getTotalUnitOfWater(bars));
        
    }
    
}
