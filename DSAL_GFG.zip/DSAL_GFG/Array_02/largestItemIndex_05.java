public class largestItemIndex_05 {

    //This is an Efficienet Approach To Get the largest element's index.
    public static int getLargestElementsIndex(int numberOfElements[]){
        int firstIndex = 0;
        for(int i = 0; i < numberOfElements.length; i++){
            if(numberOfElements[i] > numberOfElements[firstIndex]){
                firstIndex = i;
            }
        }
        return firstIndex;
    }
    public static void main(String[] args) {
        int[] numberOfElements = {200,4,601,101,3};
        System.out.println("The largest element is present at the index: "+getLargestElementsIndex(numberOfElements));
    }
}
