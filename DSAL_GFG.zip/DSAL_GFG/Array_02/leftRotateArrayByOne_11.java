package DSAL_GFG.Array_02;
import java.util.Arrays;

public class leftRotateArrayByOne_11 {

    /*
     * Left Rotating in an array by one means that the first element of the array is
     * shifting to the last.
     * OR
     * The rotation that happens counter closewise is called Left Rotation.
     */
    public static int leftRotateArrayBy1(int number[]) {

        int result = 0; // indicates the first index of the array.
        for (int i = 1; i < number.length; i++) {
            if(number[i] != number[result]){
                int temp = number[result];
                number[result] = number[i];
                number[i] = temp;
                result++;
            }

            // int temp = number[0];
            // for (int j = 0; j < number.length; j++) {
            //     number[i-1] = number[i];
            // }
            // number[size-1] = temp;
        }
        return result;
    }

    public static void main(String[] args) {
        int[] number = { 11, 21, 13, 41, 51, 16, 71, 18, 91 };

        System.out.println("Before Left Rotating an array by one: " + Arrays.toString(number));

        leftRotateArrayBy1(number);

        System.out.print("After Left Rotating an array by one: ");
        for (int i = 0; i < number.length; i++) {
            System.out.print(number[i] + " ");
        }
        System.out.println("\n");
    }
}
