package DSAL_GFG.Array_02;

public class maxLengthEvenOddSubArray_19 {

    // Find the length of the longest subarray that has alternating even odd elements.
    /* 
    Alternating means: 
    number = {
        1stOdd, 2stndEven,
        3rdOdd,4thEven,5thOdd,
        6thEven,7thEven,8thEven,
        9thOdd
    }
    we have to count or find the maximum length of the odd or even consecutively present items in the given array.

    */
    public static int getMaxEvenOddSubArray(int number[]){

        int finalMaxEvenOdd = 0;
        int currentMaxEvenOdd = 0;
        for (int i = 1; i < number.length; i++) {
            if((number[i] % 2 == 0 && number[i-1]%2 != 0) || (number[i] %2 != 0 && number[i-1] % 2 == 0)){
                currentMaxEvenOdd++;
                finalMaxEvenOdd = Math.max(finalMaxEvenOdd, currentMaxEvenOdd);
            }
            else{
                currentMaxEvenOdd = 1;
            }
        }
        return finalMaxEvenOdd; 
    }

    public static void main(String[] args) {
        int[] number = {10,12,13,14,7,4,3,15,19};
        System.out.println("\nThe maximum or total consecutive length of even and odd in the array is: "+getMaxEvenOddSubArray(number));
        System.out.println("\n");
    }
    
}
