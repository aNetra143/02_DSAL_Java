package DSAL_GFG.Array_02;

public class maximumCircularSumSubArray_20 {

    /*
    Q. The task is to find the maximum cicular sum subarray of a given array.

    Time complexity: O(n).

    Given array: {10,5,-5}

    normal subarray: {10}, {5}, {-5},{10,5},{5,-5},
    {10,5,-5}

    Circular sub-array: {5,-5,10}, {-5,10}, {-5,10,5}

    Circular sub-array: form by connecting last elements back to first element.  
    */
    public static void main(String[] args) {
      
        
    } 
}


