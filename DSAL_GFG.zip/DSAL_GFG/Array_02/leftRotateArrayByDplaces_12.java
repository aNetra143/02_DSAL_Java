import java.util.*;
import java.io.*;
import java.lang.*;

class leftRotateArrayByDplaces_12 {

    /*
     * For example:
     * number = [1,2,3,4,5,6,7,8,9,10,11];
     * d = 2;
     * 
     */
    static void leftRotate(int arr[], int d, int n) {

        int temp[] = new int[d];
        for (int i = 0; i < d; i++) {
            temp[i] = arr[i];
        }

        for (int i = d; i < n; i++) {
            arr[i - d] = arr[i];
        }

        for (int i = 0; i < d; i++) {
            arr[n - d + i] = temp[i];
        }
    }

    public static void main(String args[]) {
        int arr[] = { 1, 2, 3, 4, 5 ,6,7,8,9}, n = 9, d = 4;

        System.out.println("Before Rotation");

        for (int i = 0; i < n; i++) {
            System.out.print(arr[i] + " ");
        }

        System.out.println();
        leftRotate(arr, d, n);

        System.out.println("After Rotation");
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println("\n");

    }

}