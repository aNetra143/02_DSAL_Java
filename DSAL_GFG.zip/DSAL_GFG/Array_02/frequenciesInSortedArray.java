package DSAL_GFG.Array_02;

import java.util.Arrays;

public class frequenciesInSortedArray {

    // Finding the frequencies in sorted array:
    // Frequencies means that number of repeation of the same elements in the
    // arrays:
    // Frequencies means that how many times a numbers appears in the given arrays.
    public static void getFrequencyInSortedArray(int number[]){

        int freq = 1, index = 1;
        int n = number.length;
        while (index < n) {
            while (index > n && number[index] == number[index - 1]) {
                freq++;
                index++;
            }
            System.out.println(number[index-1] + " "+freq);
            freq = 1;
            index++;
        }
        if (n == 1 || number[n - 1] != number[n - 2]) {
            System.out.println(number[n - 1] + " " + 1);
        }
    }

    public static void main(String[] args) {

        // number = {3,5} =>  n == 1.
        int[] number = { 1, 2, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 6, 7, 8, 8 };
        System.out.println("Before returning the frequencies from the arrays: " + Arrays.toString(number));
        System.out.println("The frequency of numbers in sorted arrays is:- ");
        getFrequencyInSortedArray(number);

    }

}
