package DSAL_GFG.Array_02;
public class vectorscpp_02 {
    /*
     * Array In DSAL:
     */
    public static void main(String[] args) {

        /*
         * 1. Vectors In Array:
         * -> Dynamic Size.
         * -> Rich library Function find, erase, insert etc.
         * -> Easy to know size.
         * -> No need to pass size.
         * -> Can be returned from a function.
         * -> By default initialized with default values.
         * -> We can copy a vector to other like v1 = v2.
         */

        /*
         * 2. ArrayList In Java:
         * -> Dynamic Size.
         * -> Rich Library Functions.
         * -> eg: Online students:- 200 but students present is about more than 1000 on that's condition arrayList comes to use.
         */

    }
}
